import requests
from config_test import base_api_endpoint, headers, auth

# positive - valid data
positive_post_payload = {
    'author': 'David Goggins',
    'quote': 'test quote'
}

# valid data response
positive_expected_post_payload_response = {
    'author': 'David Goggins',
    'quote': 'test quote',
    'status': 'PENDING'
}

# negative - invalid data
negative_post_payload = {
    'author': 'David Goggins',
    'quote': 'test quote',
    'status': ''
}

# invalid data response
negative_expected_post_response = {
    'message': 'You cannot include a status when creating a new quote'
}


# positive test
def test_positive_post_with_auth(base_api_endpoint, headers, auth):
    response = requests.post(base_api_endpoint, headers=headers, json=positive_post_payload, auth=auth)

    assert response.status_code == 200, f'Actual Status Code: {response.status_code}, Expected Status Code: 200'
    positive_post_response = response.json()

    assert positive_post_response['author'] == 'David Goggins', (
        f'Expected: David Goggins, Actual: {positive_post_response.get('author')}'
    )
    assert positive_post_response['quote'] == 'test quote', (
        f'Expected: test quote, Actual: {positive_post_response.get("quote")}'
    )
    assert 'id' in positive_post_response
    assert 'tags' in positive_post_response


# negative test
def test_negative_post_with_auth(base_api_endpoint, headers, auth):
    response = requests.post(base_api_endpoint, headers=headers, auth=auth, json=negative_post_payload)

    assert response.status_code == 400, f'Actual Status Code: {response.status_code}, Expected Status Code: 400'
    negative_post_response = response.json()


# test app stability with a GET request
    response = requests.get(base_api_endpoint, headers=headers, auth=auth)
    assert response.status_code == 200, f'Actual Status Code: {response.status_code}, Expected Status Code: 200'

import request from "supertest";
import app from "../../../../app.js";
import {expect} from "chai";
import {apiPath} from "../../fixtures/testSetup.spec.js";

let quoteId = "";

describe(`PUT ${apiPath}:id to update entire quote object`, () => {
    beforeEach("Create new quote", done => {
        let quoteToUpdateViaPut = {
            quote: "Test quote for put command",
            author: "Test author for put",
            tags: ["origin_tag1", "origin_tag2"]
        }
        request(app)
            .post(apiPath)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(quoteToUpdateViaPut)
            .expect(200)
            .then(response => {
                quoteId = response.body.id;
                done();
            }).catch(done);
    });
    it('should update the update all quote fields', done => {
        let newQuoteViaPut = {
            quote: "Updated test quote for put command",
            author: "Updated test author for put"
        }
        request(app)
            .put(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).to.be.equal(200);
                expect(response.body).to.be.an("object");
                expect(response.body.author).to.be.equal("Updated test author for put")
                expect(response.body.quote).to.be.equal("Updated test quote for put command")
                expect(response.body.status).to.be.equal("PENDING")
                expect(response.body.tags).to.be.an("array")
                expect(response.body.tags).to.deep.equal([])
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    })
    it('should update the status to ACTIVE', done => {
        let newQuoteViaPut = {
            quote: "Updated test quote for put command",
            author: "Updated test author for put",
            status: "ACTIVE"
        }
        request(app)
            .put(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).to.be.equal(200);
                expect(response.body).to.be.an("object");
                expect(response.body.author).to.be.equal("Updated test author for put")
                expect(response.body.quote).to.be.equal("Updated test quote for put command")
                expect(response.body.status).to.be.equal("ACTIVE")
                expect(response.body.tags).to.be.an("array")
                expect(response.body.tags).to.deep.equal([])
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    })

    it('should update the tags', done => {
        let newQuoteViaPut = {
            quote: "Updated test quote for put command",
            author: "Updated test author for put",
            tags: ["put_tag1", "put_tag2","put_tag3"]
        }
        request(app)
            .put(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).to.be.equal(200);
                expect(response.body).to.be.an("object");
                expect(response.body.author).to.be.equal("Updated test author for put")
                expect(response.body.quote).to.be.equal("Updated test quote for put command")
                expect(response.body.status).to.be.equal("PENDING")
                expect(response.body.tags).to.be.an("array")
                expect(response.body.tags).to.deep.equal(["put_tag1","put_tag2","put_tag3"])
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    })

    it('should update the tags for quote object', done => {
        let newQuoteViaPut = {
            quote: "Updated test quote for put command",
            author: "Updated test author for put",
            tags: ["put_tag1", "put_tag2","put_tag3"]
        }
        request(app)
            .put(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).to.be.equal(200);
                expect(response.body).to.be.an("object");
                expect(response.body.author).to.be.equal("Updated test author for put")
                expect(response.body.quote).to.be.equal("Updated test quote for put command")
                expect(response.body.status).to.be.equal("PENDING")
                expect(response.body.tags).to.be.an("array")
                expect(response.body.tags).to.deep.equal(["put_tag1","put_tag2","put_tag3"])
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    })


    it('should update the source for quote object', done => {
        let newQuoteViaPut = {
            quote: "Updated test quote for put command",
            author: "Updated test author for put",
            source: "Youtube"
        }
        request(app)
            .put(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).to.be.equal(200);
                expect(response.body).to.be.an("object");
                expect(response.body.author).to.be.equal("Updated test author for put")
                expect(response.body.quote).to.be.equal("Updated test quote for put command")
                expect(response.body.status).to.be.equal("PENDING")
                expect(response.body.source).to.be.equal("Youtube")
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    })

    it('should error when author not included', done => {
        let newQuoteViaPut = {
            quote: "Updated test quote for put command",
            tags: ["put_tag1", "put_tag2","put_tag3"]
        }
        request(app)
            .put(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).to.be.equal(400);
                expect(response.body).to.be.an("object");
                expect(response.body.message).to.be.equal("author and quote are required to update.")
                expect(response.body.body.quote).to.be.equal("Updated test quote for put command")
                expect(response.body.body.tags).to.be.an("array")
                expect(response.body.body.tags).to.deep.equal(["put_tag1","put_tag2","put_tag3"])
                done();
            }).catch(done);
    })

    it('should error when quote not included', done => {
        let newQuoteViaPut = {
            author: "Updated test author for put command",
            tags: ["put_tag1", "put_tag2","put_tag3"]
        }
        request(app)
            .put(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).to.be.equal(400);
                expect(response.body).to.be.an("object");
                expect(response.body.message).to.be.equal("author and quote are required to update.")
                expect(response.body.body.author).to.be.equal("Updated test author for put command")
                expect(response.body.body.tags).to.be.an("array")
                expect(response.body.body.tags).to.deep.equal(["put_tag1","put_tag2","put_tag3"])
                done();
            }).catch(done);
    });

    it('should error when not existent valid id is passed', done => {
        let newQuoteViaPut = {
            author: "Updated test author for put command",
            quote: "test quote"
        }
        request(app)
            .put(`${apiPath}6646d4c51ce39e135dbaefe3`)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .then(response => {
                console.log(response.body);
                console.log(response.body);
                expect(response.statusCode).is.equal(404);
                expect(response.body).to.be.an("object");
                done();
            }).catch(done);
    });

    it('should error when not existent invalid id is passed', done => {
        let newQuoteViaPut = {
            author: "Updated test author for put command",
            quote: "test quote"
        }
        request(app)
            .put(`${apiPath}6646d4c51ce39e135dbaefe333`)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(newQuoteViaPut)
            .then(response => {
                console.log(response.body);
                console.log(response.body);
                expect(response.statusCode).is.equal(400);
                expect(response.body).to.be.an("object");
                done();
            }).catch(done);
    });
})
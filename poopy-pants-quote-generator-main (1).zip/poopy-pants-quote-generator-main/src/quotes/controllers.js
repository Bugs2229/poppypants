import QuoteModel from "./model.js";

export async function generateActiveRandomQuote(author) {
    let listOfQuotes = await getListFilteredQuotes(author);
    let totalAmountOfQuotes = listOfQuotes.length;
    console.log("Total Amount of Quotes: " + totalAmountOfQuotes);
    if (totalAmountOfQuotes > 0) {
        let quoteToDisplay = Math.floor(Math.random() * totalAmountOfQuotes);
        console.log("Quote position: " + quoteToDisplay)
        console.log("in controller: " + listOfQuotes[quoteToDisplay])
        return listOfQuotes[quoteToDisplay];
    } else {
        return {};
    }

}

function getListFilteredQuotes(author) {
    return QuoteModel.find({
        author: author,
        status: "ACTIVE"
    }).select('status author quote tags added_on source').exec();
}
import {generateActiveRandomQuote} from "../../../quotes/controllers.js";
import {expect} from "chai";
import {mongo, ObjectId} from "mongoose";


describe("TEST Controller returns a random quote", () => {
    it("should return a list of active David Goggins quote",  async () => {
        const getRandomQuote = await generateActiveRandomQuote("David Goggins")
        console.log(getRandomQuote);
        console.log(getRandomQuote["status"]);
        expect(getRandomQuote["status"]).to.be.equal("ACTIVE");
        expect(getRandomQuote["author"]).to.be.equal("David Goggins");
        expect(getRandomQuote["quote"]).to.be.oneOf(
            ["Nobody cares what you did yesterday. What have you done today to better yourself?",
                "testing during scrum meeting"]);
    })
})
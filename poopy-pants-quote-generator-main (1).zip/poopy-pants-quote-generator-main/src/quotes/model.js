import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const QuoteSchema = new Schema({
    quote: {
        type: String,
        required: true,
        validate: {
            validator: function(v) {
                return /(.*)([A-Za-z]+)(.*)/.test(v);
            }
        }
    },
    author:  {
        type: String,
        required: true,
        validate: {
            validator: function(v) {
                return /(.*)([A-Za-z]+)(.*)/.test(v);
            }
        }
    },
    source:  {
        type: String,
    },
    status: {
        type: String,
        default: "PENDING",
        enum: ["PENDING","ACTIVE","INACTIVE","DELETED"],
        required: true
    },
    tags:  [{
        type: String,
    }],
    added_by:  {
        type: String,
    },
    added_on: {
        type: Date,
        default: Date.now,
    },
    updated_on: {
        type: Date,
    },
    shares:  {
        type: Number,
    },
    likes:  {
        type: Number,
    },
    dislikes:  {
        type: Number
    },
},
    {collection: 'quotes_collection'});
QuoteSchema.set('toJSON',
    { getters: true,
        virtuals: true,
        transform:
            function (doc,
                      ret)
            {   delete ret._id;
                delete ret.__v;
            }});
const  QuoteModel = mongoose.model("Quote", QuoteSchema);
export default QuoteModel;
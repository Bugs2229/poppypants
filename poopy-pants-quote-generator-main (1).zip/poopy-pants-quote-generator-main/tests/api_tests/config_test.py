import pytest
import os
from requests.auth import HTTPBasicAuth


# endpoint fixture
@pytest.fixture
def base_api_endpoint():
    return 'http://localhost:3000/api/quotes'


# header fixture
@pytest.fixture
def headers():
    return {'Content-Type': 'application/json'}


@pytest.fixture
def auth():
    username = os.environ['BASIC_AUTH_USER']
    password = os.environ['BASIC_AUTH_PASSWORD']

    if not username or not password:
        raise ValueError("Missing USERNAME or PASSWORD")

    return HTTPBasicAuth(username, password)


# quote ids
@pytest.fixture
def quote_id():
    return '66270be4d0da59c703a34336'


# invalid quote id for negative PATCH test
@pytest.fixture
def not_found_quote_id():
    return '66270be4d0da59c703a343ab'


# invalid quote id used for the negative delete test
@pytest.fixture
def delete_quote_id():
    return '6627ebb72fbe03208ee5d2de'


@pytest.fixture
def delete_request_endpoint(base_api_endpoint, delete_quote_id):
    return f'{base_api_endpoint}/{delete_quote_id}'


# random endpoint url
@pytest.fixture
def random_endpoint():
    return 'http://localhost:3000/api/quotes/random'

import requests
from config_test import base_api_endpoint, headers, auth, quote_id, not_found_quote_id

positive_patch_payload = {
    'author': 'test PATCH author',
    'quote': 'test PATCH quote',
    'status': "INACTIVE"
}


def test_positive_patch_api_request(base_api_endpoint, headers, auth, quote_id):
    patch_api_endpoint = f'{base_api_endpoint}/{quote_id}'
    response = requests.patch(patch_api_endpoint, headers=headers, auth=auth, json=positive_patch_payload)
    assert response.status_code == 200, (
        f'Actual Status Code: {response.status_code}, Expected: 200'
    )
    patch_response_body = response.json()
    for key, expected_value in positive_patch_payload.items():
        assert patch_response_body.get(key) == expected_value, (
            f'For key{key}, Actual Response Value: {patch_response_body.get(key)}, '
            f'Expected Response Value: {expected_value}'
        )
    assert patch_response_body.get('id') == f'{quote_id}', (
        f'Actual Response ID: {patch_response_body.get("id")}',
        f'Expected Response ID: {quote_id}'
    )


def test_not_found_id_patch_api_request(base_api_endpoint, headers, auth, not_found_quote_id):
    patch_api_endpoint = f'{base_api_endpoint}/{not_found_quote_id}'
    response = requests.patch(patch_api_endpoint, headers=headers, auth=auth, json=positive_patch_payload)
    assert response.status_code == 404, f'Actual Status Code: {response.status_code}, Expected: 404'

    not_found_response_body = response.json()
    assert not_found_response_body.get('id') == not_found_quote_id
    assert not_found_response_body.get('message') == f'The requested quote id: {not_found_quote_id} could not be found.'

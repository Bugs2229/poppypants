# IMPORT STUFF
import requests
from config_test import random_endpoint, auth


def test_random_get(random_endpoint, auth):
    url = f'{random_endpoint}' + '?author=David%20Goggins'
    response = requests.get(url, auth=auth)
    print(f"API endpoint URL: {url}")
    print(f"Response status code: {response.status_code}")
    print(f"Response content: {response.content}")

    # Verify the response status code (expecting an error response)
    assert response.status_code == 200, f"Expected a 200 status code, and received {response.status_code}"

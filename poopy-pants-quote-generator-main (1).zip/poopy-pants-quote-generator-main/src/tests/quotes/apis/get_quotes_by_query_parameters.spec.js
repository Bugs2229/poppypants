import request from "supertest";
import {expect} from "chai";
import util from 'util';
import QuoteModel from "../../../quotes/model.js";
import getAllQuotes from "../../fixtures/database/quotes_fixtures.js";

import {
    addDataToCollection, createCollection,
    dbConnect,
    dbDisconnect,
    dropCollection
} from "../../utils/dbHandler.utils.js";
import app from "../../../../app.js";
import {response} from "express";
import {mongo} from "mongoose";
import {apiPath} from "../../fixtures/testSetup.spec.js";

describe(`TEST GET ${apiPath} Quotes by Query Parameters`, async() => {
    it(`GET | 200 OK | ${apiPath}?author=David Goggins`,  (done) => {
        request(app)
            .get(apiPath + "?author=David Goggins")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(200)
            .then((response) => {
                console.log(response.body)
                expect(response.status).to.be.equal(200);
                expect(response.body).to.be.an("array");
                expect(response.body).to.have.lengthOf(3);
                expect(response.body[0]).to.have.property("author").equal("David Goggins");
                expect(response.body[1]).to.have.property("author").equal("David Goggins");
                expect(response.body[2]).to.have.property("author").equal("David Goggins");
                done();
            })
            .catch(done);
    });

    it(`GET | 200 OK | ${apiPath}?source=billboard`,  (done) => {
        request(app)
            .get(apiPath + "?source=billboard")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(200)
            .then(response => {
                expect(response.status).to.equal(200);
                expect(response.body).to.be.an("array");
                expect(response.body).to.have.lengthOf(1);
                expect(response.body[0]).to.have.property("source").equal("billboard");
                expect(response.body[0]).to.have.property("id").equal("66209eef084ef5ce535b1755");
                expect(response.body[0]).to.have.property("quote").equal("test 123");
                expect(response.body[0]).to.have.property("status").equal("PENDING");
                expect(response.body[0]).to.have.property("tags").to.be.an("array");
                expect(response.body[0]).to.have.property("added_on").equal("2024-04-18T04:17:51.365Z");
                done();
            })
            .catch(done);
    });

    it(`GET | 200 OK | ${apiPath}?tags=motivation`,  (done) => {
        request(app)
            .get(apiPath + "?tags=motivation")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(200)
            .then(response => {
                expect(response.status).to.equal(200);
                expect(response.body).to.be.an("array");
                expect(response.body).to.have.lengthOf(2);
                expect(response.body[0]).to.have.property("author").to.equal("David Goggins");
                expect(response.body[0]).to.have.property("id").to.equal("65f2c0c67755a325187815f8");
                expect(response.body[0]).to.have.property("quote").to.equal("Nobody cares what you did yesterday. What have you done today to better yourself?");
                expect(response.body[0]).to.have.property("tags").to.be.deep.equal([
                    "motivation",
                    "grit",
                    "determination",
                    "discipline",
                    "focus"
                ])

                expect(response.body[1]).to.have.property("author").to.equal("David Goggins");
                expect(response.body[1]).to.have.property("id").to.equal("65f78140ac1ced9f2331278d");
                expect(response.body[1]).to.have.property("status").to.equal("PENDING");
                expect(response.body[1]).to.have.property("quote").to.equal("testing during scrum meeting with tags");
                expect(response.body[1]).to.have.property("tags").to.be.deep.equal([
                    "motivation",
                    "grit",
                    "determination",
                    "discipline",
                    "focus"
                ])

                done();
            }).catch(done);
    });

        it(`GET | 200 OK | ${apiPath}?tags=test_tag1&tags=test_tag2`,  (done) => {
            request(app)
                .get(apiPath + "?tags=test_tag1&tags=test_tag2")
                .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
                .expect(200)
                .then(response => {
                    console.log(response.body)
                    expect(response.status).to.equal(200);
                    expect(response.body).to.be.an("array");
                    expect(response.body).to.have.lengthOf(1);
                    expect(response.body[0]).to.have.property("author").to.equal("test");
                    expect(response.body[0]).to.have.property("id").to.equal("6617a80e88ec09556cfdfae4");
                    expect(response.body[0]).to.have.property("quote").to.equal("123456");
                    expect(response.body[0]).to.have.property("tags").to.be.deep.equal(["test_tag1","test_tag2"]);
                    done();
                }).catch(done);

    });
        // todo enable after fixing case sensitive queries
    /*it(`GET | 200 OK | ${apiPath}?tags=test_taG1&tags=Test_tag2 | Case Sensitivity`,  (done) => {
        request(app)
            .get(apiPath + "?tags=test_taG1&tags=Test_tag2")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(200)
            .then(response => {
                console.log(response.body)
                expect(response.status).to.equal(200);
                expect(response.body).to.be.an("array");
                expect(response.body).to.have.lengthOf(1);
                expect(response.body[0]).to.have.property("author").to.equal("test");
                expect(response.body[0]).to.have.property("id").to.equal("6617a80e88ec09556cfdfae4");
                expect(response.body[0]).to.have.property("quote").to.equal("123456");
                expect(response.body[0]).to.have.property("tags").to.be.deep.equal(["test_tag1","test_tag2"]);
                done();
            }).catch(done);

    });*/
        // todo this test is failing. bug being created. need to figure out how to get the order not to matter for tags
    /*it("GET | 200 OK | /quotes?tags=test_tag2&tags=test_tag3",  (done) => {
        request(app)
            .get("/quotes?tags=test_tag3&tags=test_tag2")
            .expect(200)
            .then(response => {
                console.log(response.body)
                expect(response.status).to.equal(200);
                expect(response.body).to.be.an("array");
                expect(response.body).to.have.lengthOf(1);
                expect(response.body[0]).to.have.property("author").to.equal("test");
                expect(response.body[0]).to.have.property("id").to.equal("6617b56ca25ea2365c5019ad");
                expect(response.body[0]).to.have.property("quote").to.equal("aA");
                expect(response.body[0]).to.have.property("tags").to.be.deep.equal(["test_tag2","test_tag3"]);
                done();
            }).catch(done);

    });*/
    it(`GET | 200 OK | ${apiPath}?status=ACTIVE`,  done => {
        request(app)
            .get(apiPath + "?status=ACTIVE")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(200)
            .then(response => {
                expect(response.status).equal(200);
                expect(response.body).to.be.an("array");
                expect(response.body[0]).to.have.property("status").to.equal("ACTIVE");
                done();
            }).catch(done);

    });
});

const createQuote = {
    tags: ['Quotes'],
    description: 'Create a new quote in the database',
    operationId: 'createQuote',
    security: [
        {
            basicAuth: [],
        },
    ],
    requestBody: {
        content: {
            'application/json': {
                schema: {
                    $ref: '#/components/schemas/createQuoteBody'
                },
            },
        },
        required: true
    },
    responses: {
        '200': {
            description: 'Quote successfully added to database',
            content: {
                'application/json': {
                    schema: {
                        type: 'object',
                        properties: {
                            id: {
                                type: 'string',
                                example: '664c105ab63de9adc889f423'
                            },
                            quote: {
                                type: 'string',
                                example: "The things I don't enjoy that I still do, that's where growth is at.",
                            },
                            author: {
                                type: 'string',
                                example: 'David Goggins',
                            },
                            status: {
                                type: 'string',
                                example: 'Pending',
                            },
                            tags: {
                                type: 'array',
                                example: '["tag1", "tag2", "tag3"]'
                            },
                            added_on: {
                                type: 'datetime',
                                example: "2024-05-21T03:09:14.172Z"
                            },
                        },
                    },
                },
            },
        },
    },
};

const createQuoteBody = {
    type: 'object',
    properties: {
        quote: {
            type: 'string',
            example: "The things I don't enjoy that I still do, that's where growth is at.",
        },
        author: {
            type: 'string',
            example: 'David Goggins',
        },
        source: {
            type: 'string',
            example: "Can't Hurt Me by David Goggins"
        },
        tags: {
            type: 'array',
            example: '["tag1", "tag2", "tag3"]'
        }
    }
};

const getQuoteById = {
    tags: ['Quotes'],
    description: 'Retrieve quote in the database by ID',
    operationId: 'getQuoteById',
    security: [
        {
            basicAuth: [],
        },
    ],
    parameters: [{
        name: 'id',
        in: 'path',
        description: 'Quote ID',
        required: true,
        type: 'string',
    }],
    responses: {
        '200': {
            description: 'Quote successfully added to database',
            content: {
                'application/json': {
                    schema: {
                        type: 'object',
                        properties: {
                            id: {
                                type: 'string',
                                example: '664c105ab63de9adc889f423'
                            },
                            quote: {
                                type: 'string',
                                example: "The things I don't enjoy that I still do, that's where growth is at.",
                            },
                            author: {
                                type: 'string',
                                example: 'David Goggins',
                            },
                            status: {
                                type: 'string',
                                example: 'Pending',
                            },
                            tags: {
                                type: 'array',
                                example: '["tag1", "tag2", "tag3"]'
                            },
                            added_on: {
                                type: 'datetime',
                                example: "2024-05-21T03:09:14.172Z"
                            },
                        },
                    },
                },
            },
        },
    },
}

const getAllQuotes = {
    tags: ['Quotes'],
    description: 'Retrieve all quotes in the database',
    operationId: 'getAllQuotes',
    security: [
        {
            basicAuth: [],
        },
    ],
    responses: {
        '200': {
            description: 'Quote successfully added to database',
            content: {
                'application/json': {
                    schema: {
                        type: 'array',
                        items: {
                            properties: {
                                id: {
                                    type: 'string',
                                    example: '664c105ab63de9adc889f423'
                                },
                                quote: {
                                    type: 'string',
                                    example: "The things I don't enjoy that I still do, that's where growth is at.",
                                },
                                author: {
                                    type: 'string',
                                    example: 'David Goggins',
                                },
                                status: {
                                    type: 'string',
                                    example: 'Pending',
                                },
                                tags: {
                                    type: 'array',
                                    example: '["tag1", "tag2", "tag3"]'
                                },
                                added_on: {
                                    type: 'datetime',
                                    example: "2024-05-21T03:09:14.172Z"
                                },
                            },
                        },
                    },
                },
            },
        },
    },
}


const putQuoteById = {
    tags: ['Quotes'],
    description: 'Update an existing quote in the database via PUT method',
    operationId: 'putQuote',
    security: [
        {
            basicAuth: [],
        },
    ],
    parameters: [{
        name: 'id',
        in: 'path',
        description: 'Quote ID',
        required: true,
        type: 'string',
    }],
    requestBody: {
        content: {
            'application/json': {
                schema: {
                    $ref: '#/components/schemas/putQuoteBody'
                },
            },
        },
        required: true
    },
    responses: {
        '200': {
            description: 'Full quote body successfully updated in the database',
            content: {
                'application/json': {
                    schema: {
                        type: 'object',
                        properties: {
                            id: {
                                type: 'string',
                                example: '664c105ab63de9adc889f423'
                            },
                            source: {
                                type: 'string',
                                example: 'Audiobook'
                            },
                            quote: {
                                type: 'string',
                                example: "The things I don't enjoy that I still do, that's where growth is at.",
                            },
                            author: {
                                type: 'string',
                                example: 'David Goggins',
                            },
                            status: {
                                type: 'string',
                                example: 'ACTIVE',
                            },
                            tags: {
                                type: 'array',
                                example: '["tag1", "tag2", "tag3"]'
                            },
                            added_on: {
                                type: 'datetime',
                                example: "2024-05-21T03:09:14.172Z"
                            },
                            updated_on: {
                                type: 'datetime',
                                example: "2024-05-21T03:12:14.172Z"
                            },
                        },
                    },
                },
            },
        },
    },
};

const patchQuoteById = {
    tags: ['Quotes'],
    description: 'Update specific fields in an existing quote in the database',
    operationId: 'createQuote',
    security: [
        {
            basicAuth: [],
        },
    ],
    parameters: [{
        name: 'id',
        in: 'path',
        description: 'Quote ID',
        required: true,
        type: 'string',
    }],
    requestBody: {
        content: {
            'application/json': {
                schema: {
                    $ref: '#/components/schemas/patchQuoteBody'
                },
            },
        },
        required: true
    },
    responses: {
        '200': {
            description: 'Quote successfully added to database',
            content: {
                'application/json': {
                    schema: {
                        type: 'object',
                        properties: {
                            id: {
                                type: 'string',
                                example: '664c105ab63de9adc889f423'
                            },
                            quote: {
                                type: 'string',
                                example: "The things I don't enjoy that I still do, that's where growth is at.",
                            },
                            author: {
                                type: 'string',
                                example: 'David Goggins',
                            },
                            status: {
                                type: 'string',
                                example: 'Pending',
                            },
                            tags: {
                                type: 'array',
                                example: '["tag1", "tag2", "tag3"]'
                            },
                            added_on: {
                                type: 'datetime',
                                example: "2024-05-21T03:09:14.172Z"
                            },
                        },
                    },
                },
            },
        },
    },
};

const randomQuoteByAuthor = {
    tags: ['Quotes'],
    description: 'Retrieve a random quote based on the author passed',
    operationId: 'getRandomQuoteFilteredByAuthor',
    security: [
        {
            basicAuth: [],
        },
    ],
    parameters: [{
        name: 'author',
        in: 'query',
        description: 'Author to get a random quote for',
        required: true,
        type: 'string',
    }],
    responses: {
        '200': {
            description: 'Random quote successfully returned from database',
            content: {
                'application/json': {
                    schema: {
                        type: 'object',
                        properties: {
                            id: {
                                type: 'string',
                                example: '664c105ab63de9adc889f423'
                            },
                            quote: {
                                type: 'string',
                                example: "The things I don't enjoy that I still do, that's where growth is at.",
                            },
                            author: {
                                type: 'string',
                                example: 'David Goggins',
                            },
                            status: {
                                type: 'string',
                                example: 'Active',
                            },
                            tags: {
                                type: 'array',
                                example: '["tag1", "tag2", "tag3"]'
                            },
                            added_on: {
                                type: 'datetime',
                                example: "2024-05-21T03:09:14.172Z"
                            },
                        },
                    },
                },
            },
        },
    },
}

const putQuoteBody = {
    type: 'object',
    security: [
        {
            basicAuth: [],
        },
    ],
    properties: {
        quote: {
            type: 'string',
            example: "The things I don't enjoy that I still do, that's where growth is at.",
        },
        author: {
            type: 'string',
            example: 'David Goggins',
        },
        source: {
            type: 'string',
            example: "Can't Hurt Me by David Goggins"
        },
        tags: {
            type: 'array',
            example: '["tag1", "tag2", "tag3"]'
        },
        status:{
            type: 'string',
            example: "ACTIVE",
        }
    }
};

const patchQuoteBody = {
    type: 'object',
    security: [
        {
            basicAuth: [],
        },
    ],
    properties: {
        status: {
            type: 'string',
            example: "ACTIVE",
        },
    },
};

const deleteQuoteById = {
    tags: ['Quotes'],
    description: 'Delete quote in the database by ID',
    operationId: 'deleteQuoteById',
    security: [
        {
            basicAuth: [],
        },
    ],
    parameters: [{
        name: 'id',
        in: 'path',
        description: 'Quote ID',
        required: true,
        type: 'string',
    }],
    responses: {
        '204': {
            description: 'Quote successfully deleted from database',
        },
        '400': {
            description: 'Quote is either active or not found',
        },
    },
}
export {createQuote, createQuoteBody, getQuoteById, getAllQuotes, randomQuoteByAuthor, putQuoteById, putQuoteBody, patchQuoteBody, patchQuoteById, deleteQuoteById}
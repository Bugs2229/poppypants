// makes an api call to our own quotes' endpoint.

const btnEl = document.getElementById("btn");
const apiURL = "/api/quotes/random?author=David Goggins";

async function getNewQuote() {

  const response = await fetch(apiURL);
  const data = await response.json();
  console.log(data);
  const quoteEl = document.getElementById("quote");
  const authorEl = document.getElementById("author");
  const imageEl = document.getElementById("dg-home-page");
  const buttonEl = document.getElementById("btn");
  const introEl = document.getElementById("intro-text")
  quoteEl.innerText = data.quote;
  authorEl.innerText = '-' + data.author;
  imageEl.src = "../images/david-goggins-poopy-pants.png";
  buttonEl.innerText = "I Need More Inspiration";
  introEl.innerText = "Goggins Level Inspiration";
}

btnEl.addEventListener('click', getNewQuote);

function showHiddenElements() {
  document.getElementById("quoteHeader").style.display = "block";
  document.getElementById("author").style.display = "block";
}

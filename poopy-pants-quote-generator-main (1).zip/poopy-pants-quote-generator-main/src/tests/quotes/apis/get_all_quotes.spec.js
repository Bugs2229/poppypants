import request from "supertest";
import {expect} from "chai";
import app from "../../../../app.js";
import {apiPath} from "../../fixtures/testSetup.spec.js";

describe(`TEST GET ${apiPath} endpoint stored in MongoDB`, () => {
        it('All quotes should be returned',  (done) => {
            request(app)
                .get(apiPath)
                .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
                .expect(200)
                .then((response) => {
                    expect(response.status).to.be.equal(200)
                    expect(response.body).to.be.an('array');
                    expect(response.body).to.have.lengthOf(12);
                    expect(response.body[0])
                        .to.be.a('Object');
                    expect(response.body[0])
                        .to.have
                        .keys('id', 'added_on', 'author', 'quote', 'status', 'tags');
                    expect(response.body[0])
                        .to.deep
                        .equal({
                            "id": '65f27c617755a325187815f6',
                            "added_on": "2024-03-14T04:26:09.468Z",
                            "author": "test",
                            "quote": "test",
                            "status": "PENDING",
                            "tags":[]});
                    done();
                }).catch(done);


        });
        it('Return 404 status code for wrong endpoint', (done) => {
            request(app)
                .get("/quotess")
                .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
                .expect(404)
                .then((response) => {
                    expect(response.status).to.be.equal(404);
                    done();

                }).catch(done)
        })
});
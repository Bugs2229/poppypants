import requests
from config_test import base_api_endpoint, auth, headers
# dummy post payload
dummy_payload = {
    'author': 'Dummy POST author',
    'quote': 'Dummy POST quote'
}

# positive put payload
positive_put_payload = {
    'author': 'PUT test author',
    'quote': 'PUT test quote'
}


def test_positive_put_api_request(base_api_endpoint, headers, auth):
    response = requests.post(base_api_endpoint, headers=headers, auth=auth, json=dummy_payload)
    assert response.status_code == 200, f'Actual Status Code: {response.status_code}, Expected Status Code: 200'
    test_data_post_response = response.json()

    captured_quote_id = test_data_post_response.get('id')

    response = requests.put(
        f'{base_api_endpoint}/{captured_quote_id}', headers=headers, auth=auth, json=positive_put_payload
    )
    assert response.status_code == 200, f'Actual Status Code: {response.status_code}, Expected Status Code: 200'
    positive_put_response = response.json()

    assert positive_put_response.get('status') == 'PENDING', (
        f'Actual Response Value: {positive_put_response.get('status')}', 'Expected Response Value: PENDING'
    )
    assert positive_put_response.get('id') == captured_quote_id, (
        f'Actual Response ID: {positive_put_response.get('id')}', 'Expected Response ID: {quote_id}'
    )
    assert 'tags' in positive_put_response, f"Key 'tags' not found in response."


# negative put payload
dummy_payload2 = {
    'author': 'Dummy POST 2 author',
    'quote': 'Dummy POST 2 quote'
}
negative_put_payload1 = {
    'author': 'PUT test author'
}

negative_put_payload2 = {
    'quote': 'PUT test quote'
}

negative_expected_response_payload = {
    'message': 'author and quote are required to update.'
}


def test_negative_put_api_request(base_api_endpoint, headers, auth):
    response = requests.post(base_api_endpoint, headers=headers, auth=auth, json=dummy_payload2)
    assert response.status_code == 200, f'Actual Status Code: {response.status_code}, Expected Status Code: 200'
    test_data_post_response = response.json()

    captured_quote_id2 = test_data_post_response.get('id')

    response = requests.put(
        f'{base_api_endpoint}/{captured_quote_id2}', headers=headers, auth=auth, json=negative_put_payload1)
    negative_put_response = response.json()

    assert response.status_code == 400, f'Actual Status Code: {response.status_code}, Expected Status Code: 400'

    assert negative_put_response.get('message') == negative_expected_response_payload.get('message'), (
        f'Actual Response Value: {negative_put_response.get("message")}'
        f'Expected Response Value: {negative_expected_response_payload}'
    )

    response = requests.put(
        f'{base_api_endpoint}/{captured_quote_id2}', headers=headers, auth=auth, json=negative_put_payload2)
    negative_put_response = response.json()
    assert response.status_code == 400, f'Actual Status Code: {response.status_code}, Expected Status Code: 400'

    assert negative_put_response.get('message') == negative_expected_response_payload.get('message'), (
        f'Actual Response Value: {negative_put_response.get("message")}'
        f'Expected Response Value: {negative_expected_response_payload}'
    )


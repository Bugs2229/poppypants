import mongoose from 'mongoose';
const Schema = mongoose.Schema;

// todo schema goes here
const quoteSchema = new Schema({
    quote: {
        type: String,
        required: true,
    },
    author:  {
        type: String,
    },
    source:  {
        type: String,
    },
    tags:  [{
        type: String,
    }],
    added_by:  {
        type: String,
    },
    added_on: {
        type: Date,
        default: Date.now,
    },
    shares:  {
        type: Number,
    },
    likes:  {
        type: Number,
    },
    dislikes:  {
        type: Number
    },
});

// create endpoint


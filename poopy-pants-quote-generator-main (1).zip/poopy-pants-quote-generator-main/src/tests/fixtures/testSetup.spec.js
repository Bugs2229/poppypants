import {
    addDataToCollection,
    createCollection,
    dbConnect,
    dbDisconnect,
    dropCollection
} from "../utils/dbHandler.utils.js";
import getAllQuotes from "./database/quotes_fixtures.js";

const apiPath = "/api/quotes/"

before(async () => {
    await dbConnect();
});
after(async () => {
    await dbDisconnect();
});
if (process.env.NODE_ENV === "github") {
    beforeEach(async () => await createCollection(process.env.COLLECTION_NAME));
}
beforeEach(async () => addDataToCollection(getAllQuotes));
afterEach(async () => dropCollection());

function logData(response) {
    console.log("request url: " + response.request.url)
    if (response.body !== "" || response.body!== "{}") {
        console.log(response.body)
    }
}

export { apiPath, logData };
import dotenv from 'dotenv';
dotenv.config()
import express from 'express';
const router = express.Router();
import QuoteModel from "./model.js";
import {generateActiveRandomQuote} from "./controllers.js";
const apiURL = process.env.GOOGLE_SHEET_API;
import basicAuth from "express-basic-auth";
const user = process.env.BASIC_AUTH_USER;
const pass = process.env.BASIC_AUTH_PASSWORD;
router.get('/',basicAuth({
    users: {[user]:pass},
    unauthorizedResponse: getUnauthorizedResponse
}),
    async (request, response)=> {
    try {
        const quotes = await QuoteModel
            .find(request.query)
            // .collation({locale: 'en', strength: 2})
            .select('status author quote tags added_on source');
        response.send(quotes);
    } catch (error) {
        response.status(500).send({ error });
    }
});

router.get('/random', async (req, res, next) => {
    const author = req.query["author"]
    const randomQuote = await generateActiveRandomQuote(author)
    console.log(randomQuote);
    try {
        if (Object.keys(randomQuote).length === 0) {
            res.status(404)
                .send({
                    "status": res.statusCode,
                    "message": "Sorry, there are no ACTIVE quotes available for the author: " +author})
        } else {
            res.status(200).send(randomQuote);
        }
    } catch (error) {
        res.status(500).send(error);
    }
});

router.post('/', basicAuth({
    users: {[user]:pass},
    unauthorizedResponse: getUnauthorizedResponse
}), async (req, res) => {
    if (req.body.hasOwnProperty("status")) {
        res.status(400).send({
            "status": 400,
            "message": "You cannot include a status when creating a new quote"
        });
    } else {
        const quote = new QuoteModel(req.body);
        try {
            await quote.save();
            res.send(quote);
        } catch (error) {
            res.status(400).send(error);
        }
    }

});

router.get("/:id",  basicAuth({
    users: {[user]:pass},
    unauthorizedResponse: getUnauthorizedResponse
}), async (req, res) => {
    let id = req.params.id;
    try {
        const quote
            = await QuoteModel
            .findById(id, 'status author quote tags added_on source').exec();
        if (!quote) {

            console.log("----------------- Quote ID not found: " + req.params.id + " -----------------")
            return res.status(404).send({
                    "status": res.statusCode,
                    "id": req.params.id,
                    "message": "The requested quote id: " + req.params.id + " could not be found."
                }
            )
        }
        res.send(quote);
        console.log("Successfully GET by ID: " + req.params.id)
    } catch (error) {
        res.status(400).send({
            "status": res.statusCode,
            "id": req.params.id,
            "message": req.params.id + " is not a valid quote id."
        });
        console.log("----------------- START ERROR GET by ID: " + req.params.id + " -----------------")
        console.log(error);
        console.log("----------------- END ERROR GET by ID: " + req.params.id + " -----------------")
    }
})

router.patch("/:id",basicAuth({
    users: {[user]:pass},
    unauthorizedResponse: getUnauthorizedResponse
    }), async (req, res) => {
    let id = req.params.id;
    let body = req.body;
    let listOfPropertiesInRequestBody = [];
    try {
        for (const property in (req.body)) {
            console.log(`Property to check: ${property}: ${req.body[property]}`);
            if (
                (property !== "quote" &&
                property !== "author" &&
                property !== "status" &&
                property !== "tags" &&
               property !== "source")
            ) {
                listOfPropertiesInRequestBody.push(property);
            }
        }

        if (listOfPropertiesInRequestBody.length > 0) {
            res.status(400).send({
                "status": res.statusCode,
                "id": id,
                "body": body,
                "message": listOfPropertiesInRequestBody + " is not accepted."
            })
        } else {
            body.updated_on = Date.now();
            let quote = await QuoteModel.findOneAndUpdate({"_id": id}, body, {new: true, runValidators: true}).exec();
            if (!quote) {
                console.log("----------------- Quote ID not found: " + req.params.id + " -----------------")
                return res.status(404).send({
                    "status": res.statusCode,
                    "id": req.params.id,
                    "message": "The requested quote id: " + req.params.id + " could not be found."
                })
            } else {
                res.send(quote);
            }
        }



        console.log(body);
    } catch (error) {
        console.log(error);
        res.status(400).send(error)
    }

})

router.put("/:id", basicAuth({
    users: {[user]:pass},
    unauthorizedResponse: getUnauthorizedResponse
    }), async (req, res, error) => {
    let id = req.params.id;
    let body = req.body;


    let listOfPropertiesInRequestBody = []
    try {

        for (const property in (req.body)) {
            console.log(`Property to check: ${property}: ${req.body[property]}`);
            if (
                (property !== "quote" &&
                    property !== "author" &&
                    property !== "status" &&
                    property !== "tags" &&
                    property !== "source")
            ) {
                listOfPropertiesInRequestBody.push(property);
            }
        }

        if (listOfPropertiesInRequestBody.length > 0) {
            res.status(400).send({
                "status": res.statusCode,
                "id": id,
                "body": body,
                "message": listOfPropertiesInRequestBody + " is not accepted."
            })
        } else if(body.author === undefined || body.quote === undefined) {
            res.status(400).send({
                "status": res.statusCode,
                "id": id,
                "body": body,
                "message": "author and quote are required to update."
            })
        } else {
            body.updated_on = Date.now();
            let quote = await QuoteModel.findOneAndReplace({"_id": id}, body, {new: true, runValidators: true}).exec();
            if (!quote) {
                console.log("----------------- Quote ID not found: " + req.params.id + " -----------------")
                return res.status(404).send({
                    "status": res.statusCode,
                    "id": req.params.id,
                    "message": "The requested quote id: " + req.params.id + " could not be found."
                })
            } else {
                res.send(quote);
            }
        }


        console.log(body);

    } catch (error) {
        console.log(error);
        res.status(400).send(error)
    }
})

router.delete("/:id", basicAuth({
    users: {[user]:pass},
    unauthorizedResponse: getUnauthorizedResponse
}), async (req, res, error) => {
    let id = req.params.id;
    try {
        const quote
            =  await QuoteModel
            .deleteOne({
                _id: id,
                status: {$ne: "ACTIVE"}
            }).exec();
        console.log(quote)
        if (quote.deletedCount > 0) {
            res.status(204).send();
        } else {

            res.status(400).send({
                status: res.statusCode,
                id: id,
                message: "Not able to process deletion request."
            })
        }
    } catch(error) {
        console.log(error);
        res.status(400).send({
            "status": res.statusCode,
            "id": req.params.id,
            "message": "Not able to process deletion request."
        })
    }


})

function getUnauthorizedResponse(req) {
    console.log(req.auth)
    return req.auth
        ? ({
            'status': 401,
            'message': 'Credentials rejected'})
        : {
            'status': 401,
            'message':'No credentials provided'}
}
export default router;

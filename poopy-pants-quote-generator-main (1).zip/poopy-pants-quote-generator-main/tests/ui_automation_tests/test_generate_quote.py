import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


@pytest.fixture
def driver():
    service = Service('/Users/williams/Downloads/chromedriver-mac-arm64/chromedriver')
    driver = webdriver.Chrome(service=service)
    yield driver
    driver.quit()


def test_generate_quote(driver):
    driver.get('https://poopypants.app/')

    generate_button = driver.find_element(By.ID, 'btn')
    generate_button.click()

    # Wait until elements are generated
    wait = WebDriverWait(driver, 10)

    # verify quote is displayed
    quote_element = wait.until(EC.visibility_of_element_located((By.ID, 'quoteHeader')))
    quote_element = driver.find_element(By.ID, 'quoteHeader')
    assert quote_element.text != '', 'Quote text should not be empty'

    # verify author is displayed
    author_element = wait.until(EC.visibility_of_element_located((By.ID, 'author')))
    author_element = driver.find_element(By.ID, 'author')
    assert author_element.text == '-David Goggins', f'Expected: -David Goggins, Actual: {quote_element.text}'

    # verify heading is present
    heading_element = driver.find_element(By.CLASS_NAME, 'heading')
    assert heading_element.text == ('Not Feeling It Today? Let David Goggins get you back on track! Click the button '
                                    'below!'), \
        (f'Expected: Not Feeling It Today? Let David Goggins get you back on track! Click the button below!, '
         f'Actual: {heading_element.text}')

import mongoose from 'mongoose';
import dotenv from "dotenv";
dotenv.config()
export function connectDB() {
    const url = process.env.MONGODB_URL;
    const clientOptions = { serverApi: { version: '1', strict: true, deprecationErrors: true } };


    try {
        mongoose.connect(url, clientOptions);
    } catch (err) {
        console.error(err.message);
        process.exit(1);
    }

    const dbConnection = mongoose.connection;

    dbConnection.once("open", (_) => {
        console.log(`Database connected ${url.split("@")[1]}`);
    });

    dbConnection.on("error", (err) => {
        console.error(`connection error: ${err}`);
    });

}
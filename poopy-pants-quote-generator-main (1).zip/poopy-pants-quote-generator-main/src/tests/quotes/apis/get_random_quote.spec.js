import request from "supertest";
import app from "../../../../app.js";
import {expect} from "chai";
import {apiPath} from "../../fixtures/testSetup.spec.js";

describe(`TEST GET ${apiPath}random Random Quote for Author`, async () => {
    it(`GET ${apiPath} random should return 200 and random quote for David Goggins as author and status ACTIVE`, (done) => {
        request(app)
            .get(apiPath + "random?author=David Goggins")
            .expect(200)
            .then((response) => {
                console.log(response.body);
                expect(response.status).to.equal(200);
                expect(response.body["status"]).to.be.equal("ACTIVE");
                expect(response.body["author"]).to.be.equal("David Goggins");
                expect(response.body["quote"]).to.be.oneOf(
                    ["Nobody cares what you did yesterday. What have you done today to better yourself?",
                        "testing during scrum meeting"]);
                expect(response.body["id"]).to.be.oneOf(["65f7810dac1ced9f2331278b","65f2c0c67755a325187815f8"]);
                done();
            }).catch(done);
    })
    it("GET " + apiPath + "random should return 404 when no ACTIVE quotes are found for an author", (done) => {
        request(app)
            .get(apiPath + "random?author=Random Author")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(404)
            .then((response) => {
                console.log(response.body);
                expect(response.status).to.equal(404);
                expect(response.body).to.have.property("status").equals(404);
                expect(response.body).to.have.property("message").equals("Sorry, there are no ACTIVE quotes available for the author: Random Author");
                done();
            }).catch(done);
    })
})
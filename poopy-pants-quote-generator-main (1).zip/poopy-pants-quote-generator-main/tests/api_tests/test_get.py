# IMPORT STUFF
import requests
import os
from config_test import base_api_endpoint, auth


def test_valid_get(base_api_endpoint, auth):
    url = base_api_endpoint

    response = requests.get(url, auth=auth)
    # (os.environ['BASIC_AUTH_USER'], os.environ['BASIC_AUTH_PASSWORD']))
    print(f"API endpoint URL: {url}")
    print(f"Response status code: {response.status_code}")
    print(f"Response content: {response.content}")

    # Verify the response status code (expecting an error response)
    assert response.status_code == 200, f"Expected a 200 status code, and received {response.status_code}"
    # #Returns a 400 status rather than 401?

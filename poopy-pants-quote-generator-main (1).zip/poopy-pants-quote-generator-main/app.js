import createError from 'http-errors';
import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import logger from 'morgan';
import indexRouter from './src/home/index.js';
import quotesRouter from './src/quotes/routes.js';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import swaggerUi from 'swagger-ui-express';
import { apiDocumentation } from './docs/apidoc.js';
import basicAuth from "express-basic-auth";
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
const user = process.env.BASIC_AUTH_USER;
const pass = process.env.BASIC_AUTH_PASSWORD;
app.use('/', indexRouter);

app.use('/api/quotes', quotesRouter)
app.use('/api/documentation', basicAuth({
  challenge: true,
  users: {[user]:pass},
  unauthorizedResponse: getUnauthorizedResponse
}),swaggerUi.serve, swaggerUi.setup(apiDocumentation));
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

function getUnauthorizedResponse(req) {
  console.log(req.auth)
  return req.auth
      ? ({
        'status': 401,
        'message': 'Credentials rejected'})
      : {
        'status': 401,
        'message':'No credentials provided'}
}

export default app;
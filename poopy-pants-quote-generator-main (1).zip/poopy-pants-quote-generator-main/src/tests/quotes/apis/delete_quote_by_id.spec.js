import request from "supertest";
import {expect} from "chai";
import app from "../../../../app.js";
import {apiPath, logData } from "../../fixtures/testSetup.spec.js";

describe(`TEST DELETE ${apiPath}:id  Quote by ID with ACTIVE quote`, async() => {
    it("DELETE 204 OK valid id of quote from database",  (done) => {
        request(app).delete(apiPath + "66209eef084ef5ce535b1755")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(204)
            .then(response => {
                logData(response);
                expect(response.status).to.be.equal(204)
                done();
            }).catch(done);
    });
    it("DELETE 400 Quote must not be active to delete",  (done) => {
        request(app).delete(apiPath + "6620977f636782a979571c0d")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(400)
            .then(response => {
                logData(response);
                expect(response.status).to.be.equal(400)
                expect(response.body).to.be.a('Object')
                expect(response.body).to.have
                    .keys('status', 'id', 'message');
                expect(response.body)
                    .to.deep
                    .equal({
                        "status": 400,
                        "id": "6620977f636782a979571c0d",
                        "message": "Not able to process deletion request."
                    });
                done();
            }).catch(done);
    });
    it("DELETE 400 BAD REQUEST invalid format id of quote from database",  (done) => {
        request(app).delete(apiPath + "65f27c617755a325187815f6abc")
            .expect(400)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .then((response) => {
                logData(response);
                expect(response.status).to.be.equal(400)
                expect(response.body).to.be.a('Object')
                expect(response.body).to.have
                    .keys('status', 'id', 'message');
                expect(response.body)
                    .to.deep
                    .equal({
                        "status": 400,
                        "id": "65f27c617755a325187815f6abc",
                        "message": "Not able to process deletion request."
                    });
                done();
            }).catch(done);
    });
    it("DELETE 400 NOT FOUND valid format non-existent id of quote from database",  (done) => {
        request(app).delete(apiPath + "65f27c617755a325187815f7")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(400)
            .then((response) => {
                logData(response);
                expect(response.status).to.be.equal(400)
                expect(response.body).to.be.a('Object')
                expect(response.body).to.have
                    .keys('status', 'id', 'message');
                expect(response.body)
                    .to.deep
                    .equal({
                        "status": 400,
                        "id": "65f27c617755a325187815f7",
                        "message": "Not able to process deletion request."
                    });
                done();
            }).catch(done);
    });
});
import express from 'express';
import {connectDB} from "../../config/db.js";
const router = express.Router();
if (process.env.NODE_ENV !== 'test' && process.env.NODE_ENV !== 'github') {
  connectDB();
}
/* GET home page. */
router.get('/', function(req, res, next) {
  // res.render('index', { title: 'Express' });
  res.sendFile(__dirname + "/index.html")
});

export default router;

import requests
from config_test import base_api_endpoint, auth


def test_invalid_get(base_api_endpoint, auth):
    url = base_api_endpoint + "/invalid_quote_id"

    response = requests.get(url, auth=auth)
    print(f"API endpoint URL: {url}")
    print(f"Response status code: {response.status_code}")
    print(f"Response content: {response.content}")

    # Verify the response status code (expecting an error response)
    assert response.status_code == 400, f"Expected a 400 status code, but received {response.status_code}"
    # #Returns a 400 status rather than 401?



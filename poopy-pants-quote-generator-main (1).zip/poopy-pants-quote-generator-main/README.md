# Poopy Pants Quote Generator

Welcome to the Poopy Pants Quote Generator – a project inspired by the indomitable spirit of David Goggins. This application generates motivational quotes in the style of David Goggins, encouraging you to embrace discomfort and push your limits.

## New to David Goggins? 
Let’s get you up to speed:
David Goggins is a man who redefined human limits. Once an overweight exterminator, he transformed himself into an elite ultramarathon runner, Navy SEAL, and Air Force Tactical Air Control Party member. His journey from a 300-pound struggling youth to a lean, mean machine of mental and physical toughness is nothing short of extraordinary.

Goggins' philosophy of embracing discomfort and pushing beyond perceived limits has inspired millions. He's known for his brutal honesty, unrelenting work ethic, and the mantra "Stay hard." His feats include completing over 60 ultra-endurance events, holding the Guinness World Record for pull-ups, and running 205 miles in 39 hours without sleep.

But it's not just his physical accomplishments that captivate people. Goggins' raw, no-excuses approach to life and his ability to overcome childhood trauma, learning disabilities, and racial prejudice make him a beacon of resilience. His bestselling book "Can't Hurt Me" lays bare his struggles and strategies, challenging readers to push past their own self-imposed limitations.

In a world that often seeks comfort, Goggins stands as a testament to the power of the human spirit when pushed to its absolute limits. His story isn't just about physical endurance; it's a brutal, inspiring saga of mental fortitude and the relentless pursuit of self-mastery.
![img.png](images/nobody_cares_work_harder.png)
### F**K ATTENTION & Work Harder

## Technologies Used

- **Express**: Powering the server-side of the application.
- **MongoDB & MongoDB Atlas**: Storing and retrieving quotes to ensure persistence.
- **Hashicorp Terraform**: Used to set up infrastructure on AWS & Mongo Atlas
- **AWS Elastic Beanstalk**: App in running via Node 20.12.2
- **Docker & Docker Compose**: Containerized version of the application for testing
- **Application Programming Interface (API)**: API to create, retrieve, and update quotes
- **HTML/CSS/JavaScript**: Used to serve the front-end of the application

## Getting Started
### Pre-requisities
Before you dive in, make sure you have the following installed:

* Node.js: https://nodejs.org/en/download/package-manager (v20 or later)
* MongoDB: https://www.mongodb.com/try/download/community
* Docker: https://www.docker.com/products/docker-desktop/ (for containerized deployment)
* Postman: https://www.postman.com/downloads/ (for API testing)
* MongoDB Compass: https://www.mongodb.com/try/download/compass (for database management) (optional)

### Development:

**Clone the Repository:**
   ```bash
   git clone https://github.com/techcoachralph/poopy-pants-quote-generator.git
   ```

#### Environment Variables
These environment variables should be placed in the `.env` file in the root directory of the project.
**Add Environment Variables**
- Create `.env` in root folder
- Copy environment variables below into the `.env` file
- Enter proper values for each environment variable
```
MONGODB_URL=<url-to-mongo-db-goes-here> #<username>:<password>@database-url.com/<database-name>
PPQ_DB_USER=<database-username>
PPQ_DB_PASS=<database-password>
PPQ_DB_NAME=<database-name>
COLLECTION_NAME=<database-collection>
NODE_ENV=<environment-applicatoin-is-running>
BASIC_AUTH_USER=<api-username>
BASIC_AUTH_PASSWORD=<api-password>
```
####  Developing & Local Testing

1. **Install Dependencies:**
   ```bash
   cd poopy-pants-quote-generator
   npm install
   ``` 
   
2. **Set Up MongoDB:**
   - Use Docker to run a container of MongoDB.
   - Ensure you have MongoDB installed and running.
   - Update the MongoDB connection string in the configuration.

3. **Run the Application:**
   ```bash
   npm start
   ```
4. **Explore the Quote Generator:**
   - Visit `http://localhost:3000` to experience a burst of Goggins-style motivation.

#### Testing with Docker:
Ensure that `.env` file was created and environment variables were added to the `.env` file as stated above.
1. **Start Application with Docker Compose**
   - Use the `docker-compose up` to start up the application
     - This will build the poopy-pants-app Docker image based on the configuration in the Dockerfile
     - This will create a container from the MongoDB image
       - The database name, username, password and collection specified in the `.env` file will be used to create the database
     - This will create a container from the poopy-pants-app image that was built
       - The poopy-pants-app depends on the MongoDB container steps to be completed before it creates the container
   - If you need to **rebuild** the image of the poopy pants application:
     - User the `docker-compose up -d --build poopy_pants_app`
2. **Explore the Quote Generator:**
   - Visit `http://localhost:3000` to experience a burst of Goggins-style motivation.
3. **Stop the application**
   - Use `docker-compose down` to bring down the containers

### 📜 API Documentation
Use the [API Documentation](http://localhost:3000/documentation) to Create, Retrieve, Update, Delete (coming soon) quotes.

## 🎯 Features

- **Random Quotes:** Get a dose of motivation with each click.
- **User Interaction:** Contribute your own quotes and share your favorite ones.

## 🤝 Contributing
Got what it takes to make this quote generator even more hardcore? Here's how you can contribute:

1. Fork the repository 
2. Create your feature branch 
3. Commit your changes 
4. Push to the branch 
5. Open a Pull Request

📸 Motivation in Action: Visual Ass-Kicking 🔥
![img.png](images/screenshot_app.png)

Click here to visit: [Poopy Pants](https://www.poopypants.app), the home page of our motivation factory


## 💡 Inspiration

This project is dedicated to embodying the relentless mindset of David Goggins. As he says, "Embrace the suck, take the pain."

## 📜 License

This project is licensed under the [MIT License](LICENSE).

---

*"It's not that I'm better than you, it's just that I'm willing to suffer more." - David Goggins*

Enjoy the motivation, and remember, embrace the discomfort, embrace the poopy pants!

---

[Markdown cheatsheet](https://www.markdownguide.org/cheat-sheet/)
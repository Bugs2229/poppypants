import {
    createQuote,
    createQuoteBody,
    getAllQuotes,
    getQuoteById,
    patchQuoteById,
    putQuoteById,
    randomQuoteByAuthor,
    putQuoteBody,
    patchQuoteBody, deleteQuoteById
} from "./quotes.js";

const apiDocumentation = {
    openapi: '3.0.1',
    info: {
        version: '1.0.0',
        title: 'Poopy Pants Quotes API - Documentation',
        contact: {
            name: 'Tech Coach Ralph',
            email: 'ralph@techcoachingwithralph.com',
            url: 'https://www.techcoachingwithralph.com'
        },
        license: {
            name: 'Apache 2.0',
            url: 'https://www.apache.org/licenses/LICENSE-2.0.html',
        },
        servers: [
            {
                url: 'http://localhost:3000/',
                description: 'Local Server'
            },
            {
                url: 'https://www.poopypants.app/',
                description: 'Production Server'
            }
        ],
        tags: [
            {
                name: 'Quotes'
            }
        ]
    },
    paths: {
        '/api/quotes/': {
            post: createQuote,
            get: getAllQuotes,
        },
        '/api/quotes/{id}': {
            get: getQuoteById,
            put: putQuoteById,
            patch: patchQuoteById,
            delete: deleteQuoteById
        },
        '/api/quotes/random?author={author}': {
            get: randomQuoteByAuthor,
        },

    },
    components: {
        schemas: {
            createQuoteBody,
            putQuoteBody,
            patchQuoteBody
        },
    },
};

export {apiDocumentation};
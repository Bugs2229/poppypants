import mongoose from 'mongoose';
import { MongoMemoryServer } from 'mongodb-memory-server';

const mongo = await MongoMemoryServer.create();

const uri = mongo.getUri();

const dbConnect = async () => {

    await mongoose.connect(uri);
};

const dbDisconnect = async () => {
    await mongoose.connection.dropDatabase();
    await mongoose.connection.close();
    await mongo.stop();
};

const createCollection = async () => {
    if (mongoose.connection.db.collection(process.env.COLLECTION_NAME).collectionName !== process.env.COLLECTION_NAME) {
        const collections = await mongoose.connection.db.createCollection(process.env.COLLECTION_NAME)
    }
}

const addDataToCollection = async (dataFixtureToLoad) =>{
    await mongoose.connection.db.collection(process.env.COLLECTION_NAME).insertMany(dataFixtureToLoad);
}
const dropCollection = async () => {
    const collections = await mongoose.connection.db.collections();
    for (let collection of collections) {
        await collection.drop();
    }
}

export {dbConnect, dbDisconnect, createCollection, addDataToCollection, dropCollection}
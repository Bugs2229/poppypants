import request from "supertest";
import {expect} from "chai";
import app from "../../../../app.js";
import {apiPath} from "../../fixtures/testSetup.spec.js";

describe(`TEST POST ${apiPath} endpoint to add new Quote to MongoDB`, () => {
        it("New quote should be added",  (done) => {
            const basicQuoteWithRequiredFields =  {
               "quote": "basicQuoteWithRequiredFields",
                "author": "basicAuthorWithRequiredFields"
            }
            request(app)
                .post(apiPath)
                .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
                .send(basicQuoteWithRequiredFields)
                .expect(200)
                .then((response) => {
                    expect(response.status).to.be.equal(200)
                    expect(response.body).to.be.an('object');
                    expect(response.body)
                        .to.have.keys('id', 'added_on', 'author', 'quote', 'status', 'tags');
                    done();
                }).catch(done);
        });

    it("Adding quote should return 401 Not Authorized when basic auth username is incorrect",  (done) => {
        const basicQuoteWithRequiredFields =  {
            "quote": "basicQuoteWithRequiredFields",
            "author": "basicAuthorWithRequiredFields"
        }
        request(app)
            .post(apiPath)
            .send(basicQuoteWithRequiredFields)
            .then((response) => {
                expect(response.status).to.be.equal(401)
                expect(response.body).to.be.an('object');
                expect(response.body).to.have.property("status").to.equal(401)
                expect(response.body).to.have.property("message").to.equal("No credentials provided")
                done();
            }).catch(done);
    });

    it("Adding quote should return 401 Not Authorized when Basic Auth isn't included",  (done) => {
        const basicQuoteWithRequiredFields =  {
            "quote": "basicQuoteWithRequiredFields",
            "author": "basicAuthorWithRequiredFields"
        }
        request(app)
            .post(apiPath)
            .auth("wrong_user",process.env.BASIC_AUTH_PASSWORD)
            .send(basicQuoteWithRequiredFields)
            .then((response) => {
                expect(response.status).to.be.equal(401)
                expect(response.body).to.be.an('object');
                expect(response.body).to.have.property("status").to.equal(401)
                expect(response.body).to.have.property("message").to.equal("Credentials rejected")
                done();
            }).catch(done);
    });

    it("Adding quote should return 400 Bad Request when status ACTIVE is included in the request body",  (done) => {
        const basicQuoteWithRequiredFields =  {
            "quote": "basicQuoteWithRequiredFields",
            "author": "basicAuthorWithRequiredFields",
            "status": "ACTIVE"
        }
        request(app)
            .post(apiPath)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(basicQuoteWithRequiredFields)
            .then((response) => {
                expect(response.status).to.be.equal(400)
                expect(response.body).to.be.an('object');
                expect(response.body).to.have.property("status").to.equal(400)
                expect(response.body).to.have.property("message").to.equal("You cannot include a status when creating a new quote")
                done();
            }).catch(done);
    });

    it("Adding quote should return 400 Bad Request when status PENDING is included in the request body",  (done) => {
        const basicQuoteWithRequiredFields =  {
            "quote": "basicQuoteWithRequiredFields",
            "author": "basicAuthorWithRequiredFields",
            "status": "PENDING"
        }
        request(app)
            .post(apiPath)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(basicQuoteWithRequiredFields)
            .then((response) => {
                expect(response.status).to.be.equal(400)
                expect(response.body).to.be.an('object');
                expect(response.body).to.have.property("status").to.equal(400)
                expect(response.body).to.have.property("message").to.equal("You cannot include a status when creating a new quote")
                done();
            }).catch(done);
    });
});
import request from "supertest";
import {expect} from "chai";
import util from 'util';
import QuoteModel from "../../../quotes/model.js";
import getAllQuotes from "../../fixtures/database/quotes_fixtures.js";

import {
    addDataToCollection, createCollection,
    dbConnect,
    dbDisconnect,
    dropCollection
} from "../../utils/dbHandler.utils.js";
import app from "../../../../app.js";
import {apiPath} from "../../fixtures/testSetup.spec.js";

describe(`TEST GET ${apiPath}:id  Quote by ID`, async() => {
        it("GET 200 OK valid id of quote from database",  (done) => {
            request(app).get(apiPath + "65f27c617755a325187815f6")
                .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
                .expect(200)
                .then((response) => {
                    console.log("request url: " + response.request.url)
                    console.log(response.body)
                    expect(response.status).to.be.equal(200)
                    expect(response.body).to.be.a('Object')
                    expect(response.body).to.have
                        .keys('id', 'added_on', 'author', 'quote', 'status', 'tags');
                    expect(response.body)
                        .to.deep
                        .equal({
                            "id": '65f27c617755a325187815f6',
                            "added_on": "2024-03-14T04:26:09.468Z",
                            "author": "test",
                            "quote": "test",
                            "status": "PENDING",
                            "tags":[]});
                    done();
                }).catch(done);
        });
        it("GET 400 BAD REQUEST invalid format id of quote from database",  (done) => {
        request(app).get(apiPath + "65f27c617755a325187815f6abc")
            .expect(400)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .then((response) => {
                console.log("request url: " + response.request.url)
                console.log(response.body)
                expect(response.status).to.be.equal(400)
                expect(response.body).to.be.a('Object')
                expect(response.body).to.have
                    .keys('status', 'id', 'message');
                expect(response.body)
                    .to.deep
                    .equal({
                        "status": 400,
                        "id": "65f27c617755a325187815f6abc",
                        "message": "65f27c617755a325187815f6abc is not a valid quote id."
                        });
                done();
            }).catch(done);
    });
        it("GET 404 NOT FOUND valid format non-existent id of quote from database",  (done) => {
        request(app).get(apiPath + "65f27c617755a325187815f7")
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .expect(404)
            .then((response) => {
                console.log("request url: " + response.request.url)
                console.log(response.body)
                expect(response.status).to.be.equal(404)
                expect(response.body).to.be.a('Object')
                expect(response.body).to.have
                    .keys('status', 'id', 'message');
                expect(response.body)
                    .to.deep
                    .equal({
                        "status": 404,
                        "id": "65f27c617755a325187815f7",
                        "message": "The requested quote id: 65f27c617755a325187815f7 could not be found."
                    });
                done();
            }).catch(done);
    });
});
import requests
from config_test import random_endpoint, auth


def test_invalid_random_get(random_endpoint, auth):
    url = f'{random_endpoint}' + '?author=david%20goggins'

    response = requests.get(url, auth=auth)
# refactored the below line so only the endpoint prints
    print(f"API endpoint URL: {url}")
    print(f"Response status code: {response.status_code}")
    print(f"Response content: {response.content}")

    # Verify the response status code (expecting an error response)
    assert response.status_code != 200, f"Expected a 400 status code, and received {response.status_code}"

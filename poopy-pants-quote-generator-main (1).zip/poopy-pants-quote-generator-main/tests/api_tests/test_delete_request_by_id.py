import requests
from config_test import base_api_endpoint, delete_request_endpoint, auth, headers, delete_quote_id

dummy_payload = {
    'author': 'Dummy POST author',
    'quote': 'Dummy POST quote'
}


# send a dummy POST request to reference for DELETE request
def test_positive_delete_request_by_id(base_api_endpoint, auth, headers):
    response = requests.post(base_api_endpoint, headers=headers, auth=auth, json=dummy_payload)
    assert response.status_code == 200, f'Expected: 200 but got {response.status_code}'

# assign POST response and quote 'id' to a variable
    dummy_post_response = response.json()
    delete_request_quote_id = dummy_post_response.get('id')

# send a request to DELETE the quote id from the POST and assert status code
    delete_response = requests.delete(f'{base_api_endpoint}/{delete_request_quote_id}', headers=headers, auth=auth)
    assert delete_response.status_code == 204, f'Expected: 204 but got {delete_response.status_code}'

# verify that the quote has been deleted by sending a GET request
    verify_deleted_quote_with_get_request = requests.get(
        f'{base_api_endpoint}/{delete_request_quote_id}', headers=headers, auth=auth
    )

    assert verify_deleted_quote_with_get_request.status_code == 404, (
        f'Expected: 404 but got {verify_deleted_quote_with_get_request.status_code}'
    )


def test_negative_delete_request_by_id(delete_request_endpoint, headers, auth, delete_quote_id):
    response = requests.delete(delete_request_endpoint, headers=headers, auth=auth)
    assert response.status_code == 400, f'Expected 400, but got {response.status_code}'

    negative_delete_response = response.json()
    assert negative_delete_response.get('id') == f'{delete_quote_id}', (
        f'Expected {delete_quote_id}, but got {negative_delete_response.get('id')}'
    )
    assert negative_delete_response.get('message') == 'Not able to process deletion request.', (
        f'Expected: Not able to process deletion request and got {negative_delete_response.get('message')}'
    )

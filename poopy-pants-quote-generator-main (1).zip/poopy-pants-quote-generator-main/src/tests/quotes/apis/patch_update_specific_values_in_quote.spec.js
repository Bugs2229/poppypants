import request from "supertest";
import app from "../../../../app.js";
import {expect} from "chai";
import {apiPath} from "../../fixtures/testSetup.spec.js";

let quoteId = "";

describe(`TEST PATCH ${apiPath}:id update particular fields in quotes`, () => {
    beforeEach("Create new quote", (done) => {
        let quoteToUpdateViaPatch = {
            quote: "Test quote for patch command",
            author: "Test author for patch"
        }
        request(app)
            .post(apiPath)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(quoteToUpdateViaPatch)
            .expect(200)
            .then(response => {
                quoteId = response.body.id;
                done();
            }).catch(done);
    })

    it('should update the quote status from PENDING to ACTIVE', (done) => {
        const updateQuoteStatusJsonBody = {
           "status": "ACTIVE"
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(200);
                expect(response.body).to.be.an("object")
                expect(response.body.status).is.equal("ACTIVE");
                expect(response.body.author).is.equal("Test author for patch");
                expect(response.body.quote).is.equal("Test quote for patch command");
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    });

    it('should update the quote author from "Test author for patch" to "Updated Author"', (done) => {
        const updateQuoteAuthorJsonBody = {
            "author": "Updated Author"
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteAuthorJsonBody)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(200);
                expect(response.body).to.be.an("object")
                expect(response.body.status).is.equal("PENDING");
                expect(response.body.author).is.equal("Updated Author");
                expect(response.body.quote).is.equal("Test quote for patch command");
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    });

    it('should update the quote author and status', (done) => {
        const updateQuoteAuthorJsonBody = {
            "author": "Updated Author",
            "status": "ACTIVE"
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteAuthorJsonBody)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(200);
                expect(response.body).to.be.an("object")
                expect(response.body.status).is.equal("ACTIVE");
                expect(response.body.author).is.equal("Updated Author");
                expect(response.body.quote).is.equal("Test quote for patch command");
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    });

    it('should update the quote tags from empty to list with tags', (done) => {
        const updateQuoteStatusJsonBody = {
            "tags": ["patch_tag1","patch_tag2","patch_tag3"]
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(200);
                expect(response.body).to.be.an("object")
                expect(response.body.status).is.equal("PENDING");
                expect(response.body.tags).to.be.an("array");
                expect(response.body.tags).is.deep.equal(["patch_tag1","patch_tag2","patch_tag3"]);
                expect(response.body.quote).is.equal("Test quote for patch command");
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    });

    it('should update the quote source from empty to YouTube', (done) => {
        const updateQuoteStatusJsonBody = {
            "source": "YouTube"
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(200);
                expect(response.body).to.be.an("object")
                expect(response.body.status).is.equal("PENDING");
                expect(response.body.source).is.equal("YouTube");
                expect(response.body.quote).is.equal("Test quote for patch command");
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    });

    it('should update the actual quote to something else', (done) => {
        const updateQuoteStatusJsonBody = {
            "quote": "Updated test quote for patch command"
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(200)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(200);
                expect(response.body).to.be.an("object")
                expect(response.body.status).is.equal("PENDING");
                expect(response.body.quote).is.equal("Updated test quote for patch command");
                expect(response.body.updated_on).to.exist
                done();
            }).catch(done);
    });

    it('should give error with status is outside of schema definition', (done) => {
        const updateQuoteStatusJsonBody = {
            "status": "something else"
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(400)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(400);
                expect(response.body).to.be.an("object")
                expect(response.body.message).is.equal("Validation failed: status: `something else` is not a valid enum value for path `status`.");
                done();
            }).catch(done);
    });

    it('should give error with an empty quote', (done) => {
        const updateQuoteStatusJsonBody = {
            "quote": ""
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(400)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(400);
                expect(response.body).to.be.an("object")
                expect(response.body.message).is.equal("Validation failed: quote: Path `quote` is required.");
                done();
            }).catch(done);
    });

    it('should give error with an empty author', (done) => {
        const updateQuoteStatusJsonBody = {
            "author": ""
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(400)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(400);
                expect(response.body).to.be.an("object")
                expect(response.body.message).is.equal("Validation failed: author: Path `author` is required.");
                done();
            }).catch(done);
    });

    it('should return 400 when invalid field is entered', (done) => {
        const updateQuoteAuthorJsonBody = {
            "invalidKey": "invalidValue",
            "status": "ACTIVE"
        }
        request(app)
            .patch(apiPath + quoteId)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteAuthorJsonBody)
            .expect(400)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(400);
                expect(response.body).to.be.an("object")
                // expect(response.body.quote)("Test quote for put command");
                done();
            }).catch(done);
    });

    it('should return 404 when invalid id is passed', (done) => {
        const updateQuoteStatusJsonBody = {
            "quote": "Updated test quote for patch command"
        }
        request(app)
            .patch(`${apiPath}6646d4c51ce39e135dbaefe3`)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(404)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(404);
                expect(response.body).to.be.an("object")
                // expect(response.body.quote)("Test quote for put command");
                done();
            }).catch(done);
    });

    it('should return 400 when invalid id is passed', (done) => {
        const updateQuoteStatusJsonBody = {
            "quote": "Updated test quote for patch command"
        }
        request(app)
            .patch(`${apiPath}6646d4c51ce39e135dbaefe333`)
            .auth(process.env.BASIC_AUTH_USER,process.env.BASIC_AUTH_PASSWORD)
            .send(updateQuoteStatusJsonBody)
            .expect(400)
            .then(response => {
                console.log(response.body);
                expect(response.statusCode).is.equal(400);
                expect(response.body).to.be.an("object")
                // expect(response.body.quote)("Test quote for put command");
                done();
            }).catch(done);
    });
})
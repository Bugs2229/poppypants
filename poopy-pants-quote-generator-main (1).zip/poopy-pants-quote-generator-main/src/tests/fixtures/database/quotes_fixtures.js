import {mongo} from "mongoose";
const getAllQuotes= [
    {
        "status": "PENDING",
        "_id": new mongo.ObjectId("65f27c617755a325187815f6"),
        "quote": "test",
        "author": "test",
        "tags": [],
        "added_on": "2024-03-14T04:26:09.468Z"
    },
    {
        "status": "ACTIVE",
        "_id": new mongo.ObjectId("65f2c0c67755a325187815f8"),
        "quote": "Nobody cares what you did yesterday. What have you done today to better yourself?",
        "author": "David Goggins",
        "source": "https://quotes.mirrorreview.com/david-goggins-quotes/",
        "tags": [
            "motivation",
            "grit",
            "determination",
            "discipline",
            "focus"
        ],
        "added_on": "2024-03-14T09:17:58.370Z"
    },
    {
        "status": "ACTIVE",
        "_id": new mongo.ObjectId("65f7810dac1ced9f2331278b"),
        "quote": "testing during scrum meeting",
        "author": "David Goggins",
        "tags": [],
        "added_on": "2024-03-17T23:47:25.863Z"
    },
    {
        "status": "PENDING",
        "_id": new mongo.ObjectId("65f78140ac1ced9f2331278d"),
        "quote": "testing during scrum meeting with tags",
        "author": "David Goggins",
        "tags": [
            "motivation",
            "grit",
            "determination",
            "discipline",
            "focus"
        ],
        "added_on": "2024-03-17T23:48:16.896Z"
    },
    {
        "status": "PENDING",
        "_id": new mongo.ObjectId("6617a80e88ec09556cfdfae4"),
        "quote": "123456",
        "author": "test",
        "tags": ["test_tag1","test_tag2"],
        "added_on": "2024-04-11T09:06:22.506Z"
    },
    {
        "_id": new mongo.ObjectId("6617ac2e8c141244d66e3068"),
        "quote": "123456",
        "author": "test",
        "status": "PENDING",
        "tags": ["test_tag3","test_tag4"],
        "added_on": "2024-04-11T09:23:58.780Z"
    },
    {
        "_id": new mongo.ObjectId("6617b56ca25ea2365c5019ad"),
        "quote": "aA",
        "author": "test",
        "status": "PENDING",
        "tags": ["test_tag3","test_tag2"],
        "added_on": "2024-04-11T10:03:24.804Z"
    },
    {
        "_id": new mongo.ObjectId("6617b712c25787b3832c339e"),
        "quote": "12345abc",
        "author": "test",
        "status": "PENDING",
        "tags": [],
        "added_on": "2024-04-11T10:10:26.149Z"
    },
    {
        "_id": new mongo.ObjectId("6617b729c25787b3832c33a2"),
        "quote": "This is a test quote",
        "author": "test",
        "status": "PENDING",
        "tags": [],
        "added_on": "2024-04-11T10:10:49.868Z"
    },
    {
        "_id": new mongo.ObjectId("6617b72bc25787b3832c33a4"),
        "quote": "This is a test quote",
        "author": "test",
        "status": "PENDING",
        "tags": [],
        "added_on": "2024-04-11T10:10:51.613Z"
    },
    {
        "_id": new mongo.ObjectId("6620977f636782a979571c0f"),
        "quote": "test 123",
        "author": "tech coach ralph",
        "status": "ACTIVE",
        "tags": [],
        "added_on": "2024-04-18T03:46:07.157Z"
    },
    {
        "_id": new mongo.ObjectId("66209eef084ef5ce535b1755"),
        "quote": "test 123",
        "author": "tech coach ralph",
        "source": "billboard",
        "status": "PENDING",
        "tags": [],
        "added_on": "2024-04-18T04:17:51.365Z"
    }
]

export default getAllQuotes